"""Real-engine portal coordination: move inside, yield short heads, rescue tails.

Only candidate actions for arranging the fixture are scripted; receive, observe,
final guards, split execution and inline-length sonar emission use the real V5 code.
"""
from pathlib import Path
import subprocess,tempfile,json
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
root=Path(__file__).resolve().parents[1]
class Done(Exception):pass

def run(binary,length=2,trapped=False,outside=2):
    def dragon(team,cells):return f'DRAGON {team} {len(cells)} '+' '.join(f'{x} {y}' for x,y in cells)+'\n'
    edges=[(370,2,7),(384,2,7)]
    if trapped:edges.extend([(351,1,-1),(385,1,-1)]) # N/E blocked; S is own neck
    board='MAP 32 16\nMAP_NAME portal_hold\nTILE_COUNT 0\nEDGE_COUNT '+str(len(edges))+'\n'
    board+=''.join(f'EDGE {key} {kind} {pid}\n' for key,kind,pid in edges)
    board+='DRAGON_COUNT 3\n'+dragon(0,[(5-j,6) for j in range(outside)])
    inside=[(21+j,6) for j in range(length)]
    if length==6:inside=[(21,6),(22,6),(23,6),(23,7),(22,7),(21,7)]
    board+=dragon(0,inside)+dragon(1,[(26,12),(25,12)])+'END\n'
    pools={};live={};records=[];deaths=[];errors=[];children=[]
    def spawn(i,init):
        if i != 2:
            if i>2:children.append(i)
            pools[i]=Pool([str(binary)],cwd=str(root),size=1,key=str(i))
            live[i]=Bot(pools[i],init=init,name=str(i))
    def reply(i,block):
        lines=block.decode().splitlines();r=int(lines[0].split()[1])
        if r>=5:raise Done()
        size=int(next(l.split()[1] for l in lines if l.startswith('LENGTH ')))
        if i not in live:
            if i>2:records.append({'id':i,'round':r,'length':size,'action':'MOVE E'})
            return b'MOVE E\nPROTOCOL 3\n'
        output=live[i].ask(block)
        if live[i].error:errors.append(str(live[i].error))
        k=next(n for n,l in enumerate(lines) if l.startswith('NUM_MSGS '))
        received=[int(l) for l in lines[k+1:k+1+int(lines[k].split()[1])]]
        holds=[p for p in received if ((p>>40)&254)==0xFC]
        lengths=[p for p in received if ((p>>40)&254)==0xF8]
        sent=[l for l in output.decode().splitlines() if l.startswith('SONAR ')]
        action=next((l for l in output.decode().splitlines() if l.startswith(('MOVE ','SPLIT '))),'NONE')
        records.append({'id':i,'round':r,'length':size,'action':action,
                        'holds_received':len(holds),'hold_lengths':[(p>>36)&15 for p in holds],'lengths_received':len(lengths),'sonar':sent})
        return output
    def death(i,r,why):
        deaths.append({'id':i,'round':r,'reason':why})
        bot=live.pop(i,None)
        if bot:bot.stop()
    try:EngineModule().run(board.encode(),reply,death,spawn,on_notice=lambda _:None,seed=7)
    except Done:pass
    finally:
        for bot in live.values():bot.stop()
        for pool in pools.values():pool.close()
    result={'inside_length':length,'outside_length':outside,'trapped':trapped,
            'turns':records,'deaths':deaths,'errors':errors,'children':children}
    assert not errors,result
    sender=next(t for t in records if t['id']==0 and t['round']==1)
    sent=[l.split() for l in sender['sonar']]
    assert len(sent)<=4,result
    assert any(l[1]=='E' and ((int(l[2])>>40)&254)==0xFC for l in sent),result
    assert any(l[1]=='E' and ((int(l[2])>>40)&254)==0xFC and ((int(l[2])>>36)&15)==min(outside,15) for l in sent),result
    assert any(((int(l[2])>>40)&254)==0xF8 and ((int(l[2])>>25)&16383)==outside for l in sent),result
    receiver=next(t for t in records if t['id']==1 and t['round']==1)
    assert receiver['holds_received']>0 and min(outside,15) in receiver['hold_lengths'],result
    assert not any(d['id']==0 for d in deaths),result
    if not trapped:
        assert receiver['action'].startswith('MOVE ') and receiver['action']!='MOVE W',result
        assert not any(d['id']==1 for d in deaths),result
    elif length<=3:
        assert receiver['action']=='NONE',result
        assert any(d['id']==1 and d['round']==1 and d['reason']=='A' for d in deaths),result
    else:
        assert receiver['action']==f'SPLIT {length-2}',result
        parent=next(t for t in records if t['id']==1 and t['round']==2)
        assert parent['length']==2 and parent['action']=='NONE',result
        assert any(d['id']==1 and d['round']==2 and d['reason']=='A' for d in deaths),result
        assert children,result
        child=children[0]
        assert any(t['id']==child and t['round']==1 and t['length']==length-2 for t in records),result
        assert not any(d['id'] in children for d in deaths),result
    print(json.dumps({'inside':length,'outside':outside,'trapped':trapped,'receiver_action':receiver['action'],
                      'deaths':deaths,'children':children,'errors':len(errors)}),flush=True)
    return result

with tempfile.TemporaryDirectory(prefix='portal-hold-engine-') as temporary:
    tmp=Path(temporary);source=(root/'main.cpp').read_text()
    start=source.index('        Action action = planner.choose(ct')
    end=source.index('        Action plannedAction = action;',start)
    source=source[:start]+'''        Action action;
        if (turn.myId == 0) action = Action::move(turn.round == 1 ? 1 : 0);
        else if (turn.myId == 1 && turn.round == 0) action = Action::move(0);
        else if (turn.myId == 1 && turn.here == topology.cid(21, 5)) action = Action::move(3);
        else action = planner.choose(ct);
'''+source[end:]
    probe=tmp/'probe.cpp';probe.write_text(source);binary=tmp/'bot'
    subprocess.run(['c++','-std=c++20','-O2','-I'+str(root),str(probe),'-o',str(binary)],check=True)
    results=[run(binary),run(binary,3),run(binary,2,True),run(binary,3,True),
             run(binary,3,True,3),run(binary,4,True),run(binary,5,True),run(binary,6,True)]
    print('PASS',len(results),'real-engine portal cases')
