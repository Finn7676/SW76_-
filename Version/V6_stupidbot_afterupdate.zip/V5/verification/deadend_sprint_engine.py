"""Official 1.2.3 execution of Queen pocket policy and match 845712 geometry.
Strategy ROUND is injected; engine physics are unchanged. Not a win-rate test.
"""
from pathlib import Path
import json,subprocess,tempfile,shutil,argparse,hashlib,importlib.metadata
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--wasm',action='store_true');args=p.parse_args()
class Done(Exception):pass
def board(w,h,dragons,pearls,walls):
 text=f'MAP {w} {h}\nMAP_NAME deadend_sprint_snapshot\nTILE_COUNT {len(pearls)}\n'
 text+=''.join(f'TILE {x} {y} 1 1\n' for x,y in pearls)
 text+=f'EDGE_COUNT {len(walls)}\n'+''.join(f'EDGE {(2*y+(d=="W"))*(w+1)+x} 1 -1\n' for x,y,d in walls)
 text+=f'DRAGON_COUNT {len(dragons)}\n'
 for team,body in dragons:text+=f'DRAGON {team} {len(body)} '+' '.join(f'{x} {y}' for x,y in body)+'\n'
 return (text+'END\n').encode()
with tempfile.TemporaryDirectory(prefix='deadend-sprint-engine-') as temporary:
 tmp=Path(temporary);binary=tmp/'bot'
 subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
 argv,cwd=[str(binary)],root
 if args.wasm:
  from unswbc.run import _resolve
  from unswbc.sandbox import WasmPool,SandboxBot
  import unswbc.sandbox as sandbox
  sandbox._cache_dir=lambda:tmp/'cache'
  source=tmp/'source';source.mkdir()
  for f in root.iterdir():
   if f.suffix in ('.hpp','.cpp') or f.name=='bot.toml':shutil.copy2(f,source/f.name)
  argv,cwd,_=_resolve(str(source),True);Pool,Bot=WasmPool,SandboxBot
 results=[]
 def run(name,map_bytes,target,expected,round_label=302,remove_queens=False):
  live=pool=None;actions=[];lengths=[];peak=0;deaths=[]
  def spawn(i,data):
   nonlocal live,pool
   if i==target:pool=Pool(argv,cwd=str(cwd),size=1,key=f'0000000000000007-{i}');live=Bot(pool,init=data,name=str(i))
  def reply(i,data):
   nonlocal peak
   if remove_queens and i in (0,1):return b''
   if i!=target:return b'MOVE N\n' if remove_queens and i==3 else b'MOVE E\n'
   lines=data.splitlines();round_num=int(lines[0].split()[1]);lengths.append(int(next(l.split()[1] for l in lines if l.startswith(b'LENGTH '))))
   if round_num>=len(expected):raise Done()
   lines[0]=b'ROUND '+str(round_label+round_num).encode()
   out=live.ask(b'\n'.join(lines)+b'\n');assert not live.error,live.error
   metrics=getattr(live,'live',None)
   if metrics and metrics[0]:peak=max(peak,metrics[0])
   action=next(l for l in out.decode().splitlines() if l.startswith(('MOVE ','SPLIT ')));actions.append(action)
   want=expected[round_num]
   assert action==want if isinstance(want,str) else want(action),(name,round_num,action)
   return out
  try:EngineModule().run(map_bytes,reply,lambda i,r,w:deaths.append((i,r,w)),spawn,on_notice=lambda _:None,seed=7)
  except Done:pass
  finally:
   if live:live.stop()
   if pool:pool.close()
  assert len(actions)==len(expected) and not any(i==target for i,_,_ in deaths),(name,actions,deaths)
  results.append(dict(name=name,actions=actions,lengths=lengths,peak_cpu=peak))
 walls=[(x,5,'N') for x in range(6,9)]+[(x,6,'N') for x in range(6,9)]+[(9,5,'W')]
 for team in (0,1):
  own=[(5,5),(4,5)];other=[(13,14),(12,14)]
  dragons=[(team,own),(1-team,other)] if team==0 else [(0,other),(1,own)]
  run(f'queen{team}_refuses_entry',board(16,16,dragons,[(6,5),(7,5),(8,5)],walls),team,[lambda a:a.startswith('MOVE ') and a!='MOVE E'])
  own=[(6,5),(5,5),(4,5)]
  dragons=[(0,own),(1,other)] if team==0 else [(0,other),(1,own)]
  run(f'queen{team}_already_inside',board(16,16,dragons,[(7,5),(8,5)],walls),team,['MOVE E','MOVE E','SPLIT 3'])
 # Public replay geometry, actual visible enemy length/pearls. IDs of the nearby
 # enemy/friend are reassigned 3/4; dead Queens are represented and removed first.
 # A fresh bot lacks historical topology, so the direction can differ from the
 # known-terrain C++ reconstruction. Assert one free legal move and preserved length.
 own=[(15,4),(14,4),(13,4),(13,3),(12,3)]
 enemy=[(17,2),(17,3),(17,4)];friend=[(15,8),(15,9),(15,10),(14,10)]
 walls=[(x,y,'W') for x in (14,15,17,18) for y in (1,2,3)]
 run('match845712_round42_id2',board(32,16,[(0,[(5,12),(4,12)]),(1,[(5,14),(4,14)]),(0,own),(1,enemy),(0,friend)],[(14,1),(14,2),(17,1),(14,8)],walls),2,[lambda a:a in ('MOVE N','MOVE S')],42,True)
 assert results[-1]['lengths']==[5,5],results[-1]
 record={'toolkit':importlib.metadata.version('unswbc'),'mode':'wasm' if args.wasm else 'native','cases':results}
 (root/'verification/deadend_sprint_results.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2))
