"""Differential movement and Queen checks against the installed official engine.
Run with toolkit >=1.2.3, e.g. PYTHONPATH=/path/to/isolated/toolkit python3 this_file.py.
Does not upload, activate, or modify a user's toolkit. Native or --wasm policy checks.
"""
from pathlib import Path
from dataclasses import asdict
import subprocess, tempfile, json, importlib.metadata, argparse, hashlib, shutil
from unswbc.engine import EngineModule
from unswbc.bot import Pool, Bot
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--wasm',action='store_true');args=parser.parse_args()
version=importlib.metadata.version('unswbc')
assert tuple(map(int,version.split('.')[:3])) >= (1,2,3), f'new rules require a new engine, got {version}'
class Done(Exception):pass

def board(dragons,pearls=(),walls=()):
    text=f'MAP 16 16\nMAP_NAME queen_regression\nTILE_COUNT {len(pearls)}\n'
    text+=''.join(f'TILE {x} {y} 1 1\n' for x,y in pearls)
    text+=f'EDGE_COUNT {len(walls)}\n'+''.join(f'EDGE {k} 1 -1\n' for k in walls)
    text+=f'DRAGON_COUNT {len(dragons)}\n'
    for team,cells in dragons:text+=f'DRAGON {team} {len(cells)} '+' '.join(f'{x} {y}' for x,y in cells)+'\n'
    return (text+'END\n').encode()

def own_body(length):
    cells=[(5,5)]
    for y in range(5,13):
        xs=range(4,1,-1) if y==5 else range(2,6) if y%2==0 else range(5,1,-1)
        cells.extend((x,y) for x in xs)
    return cells[:length]

with tempfile.TemporaryDirectory(prefix='queen-engine-') as temporary:
    tmp=Path(temporary)
    # Probe uses the bot's actual observer, body model, topology and SprintModel;
    # full original body is seeded only as remembered history for hidden segments.
    probe=tmp/'probe.cpp'
    probe.write_text(r'''#include "observer.hpp"
#include "sprint.hpp"
#include <iostream>
int main(int argc,char **argv){using namespace bot;
    auto [ct,game]=init();if(!update(ct,game))return 1;
    GameConfig config(game);TurnState turn;turn.read(ct,game,config);WorldModel world(config);
    std::fill(world.edgeT.begin(),world.edgeT.end(),E_OPEN);
    Topology topology(config,world);OccupancyModel occupancy(config,turn);BodyMemory body(turn,topology,occupancy);
    Observer observer(turn,world,topology,occupancy,body);body.beginTurn();observer.observe(ct);
    std::vector<int> original;for(int i=2;i<argc;++i)original.push_back(std::stoi(argv[i]));
    body.trail.assign(original.rbegin(),original.rend());body.reconstructHidden();
    Coordination coordination(turn,world,topology,occupancy);
    SprintModel model(config,turn,topology,occupancy,body,coordination);
    Action action;action.type=ActionType::SPRINT;
    for(char c:std::string(argv[1]))action.dirs[action.steps++]=dirIndex(Direction(c));
    auto trace=model.trace(action,true);
    std::cout<<trace.legal<<' '<<trace.collision<<' '<<trace.length()<<' '<<trace.head<<'\n';
    for(int c:trace.segments)std::cout<<c<<' ';std::cout<<'\n';
}''')
    probe_bin=tmp/'probe';bot_bin=tmp/'bot'
    subprocess.run(['c++','-std=c++20','-O2','-I'+str(root),str(probe),'-o',str(probe_bin)],check=True)
    subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(bot_bin)],check=True)
    results=[]
    def movement(name,length,moves,pearls=(),own=None,enemy=None,walls=()):
        own=own or own_body(length)
        dragons=[(0,[(13,12),(12,12)]),(1,[(13,14),(12,14)]),(0,own)]
        if enemy:dragons.extend([(1,enemy),(0,[(4,7),(3,7)])])
        init={};post=None;model=None;deaths=[];drops=set();collision_body=[]
        def spawn(i,data):init[i]=data
        def reply(i,data):
            nonlocal post,model,collision_body
            lines=data.decode().splitlines();round_num=int(lines[0].split()[1])
            if round_num>=1:
                if i==2:
                    size=int(next(l.split()[1] for l in lines if l.startswith('LENGTH ')))
                    n=lines.index(next(l for l in lines if l.startswith('DRAGON_BODIES ')))
                    parts=[l.split() for l in lines[n+1:n+1+int(lines[n].split()[1])]]
                    head=next(p for p in parts if int(p[1])==2 and p[-1]=='1')
                    post={'length':size,'head':int(head[3])*16+int(head[2])};raise Done()
                if any(d[0]==2 for d in deaths):raise Done()
            if i==2:
                output=subprocess.run([str(probe_bin),moves,*[str(y*16+x) for x,y in own]],
                    input=init[i]+data,capture_output=True,check=True).stdout.decode().splitlines()
                values=list(map(int,output[0].split()));model={'legal':bool(values[0]),'collision':bool(values[1]),'length':values[2],'head':values[3]}
                collision_body=list(map(int,output[1].split()))
                return f'MOVE {moves}\n'.encode()
            if i==4:
                for line in lines:
                    fields=line.split()
                    if len(fields)==4 and all(f.lstrip('-').isdigit() for f in fields):
                        x,y,pearl,_=map(int,fields)
                        if pearl:drops.add(y*16+x)
            return b'MOVE E\n'
        try:EngineModule().run(board(dragons,pearls,walls),reply,lambda i,r,w:deaths.append((i,r,w)),spawn,on_notice=lambda _:None,seed=7)
        except Done:pass
        own_death=any(d[0]==2 for d in deaths)
        if model['legal'] and not model['collision']:
            assert not own_death and post, (name,model,post,deaths)
            assert (post['length'],post['head'])==(model['length'],model['head']), (name,model,post,deaths)
        elif model['collision']:
            assert own_death and any(d[0]==3 for d in deaths),(name,model,deaths)
            assert set(collision_body[::2]).issubset(drops),(name,collision_body,drops)
        else:assert own_death,(name,model,post,deaths)
        results.append({'case':name,'model':model,'engine_post':post,'deaths':deaths})
    for length in [2,3,4,5,8,9,12,13,16,17,20,21,24]:
        for moves in ['E','EE','EEE','EEEN','EEENN','EEENNN','EEENNNW','EEENNNWW']:
            movement(f'L{length}_{moves}',length,moves)
    movement('threshold_growth4',4,'EE',[(6,5)])
    movement('threshold_growth8',8,'EEE',[(6,5)])
    movement('early_pearl_funds_step',2,'EE',[(6,5)])
    movement('late_pearl_cannot_fund_step',2,'EE',[(7,5)])
    movement('current_tail_collision',4,'NW',own=[(5,5),(4,5),(4,4),(4,3)])
    movement('paid_head_collision',3,'EE',enemy=[(7,5),(8,5)])
    # Wall crossing after an already valid prefix.
    movement('wall_second_step',5,'EE',walls=[5*34+17+7])

    # Queen score precedes the longest dragon; queen death alone does not end a game.
    for dead in [False,True]:
        dragons=[(0,[(2,2),(1,2)]),(1,[(10,10),(9,10),(8,10)]),
                 (0,[(x,6) for x in range(10,3,-1)])]
        result=EngineModule().run(board(dragons),lambda i,b:b'MOVE E\n' if not(dead and i==0) else b'',on_notice=lambda _:None,seed=7)
        assert result.winner=='B' and result.rounds==499,(dead,asdict(result))
        assert result.a_queen==(0 if dead else 2) and result.a_longest==7,asdict(result)
        results.append({'case':'queen_scoring_dead' if dead else 'queen_scoring_alive','result':asdict(result)})

    argv,cwd=[str(bot_bin)],root
    if args.wasm:
        from unswbc.run import _resolve
        from unswbc.sandbox import WasmPool,SandboxBot
        import unswbc.sandbox as sandbox
        sandbox._cache_dir=lambda:tmp/'cache'
        snapshot=tmp/'source';snapshot.mkdir()
        for p in root.iterdir():
            if p.suffix in ('.hpp','.cpp') or p.name=='bot.toml':shutil.copy2(p,snapshot/p.name)
        digest=hashlib.sha256(b''.join(p.read_bytes() for p in sorted(snapshot.iterdir()))).hexdigest()
        with (snapshot/'main.cpp').open('a') as fp:fp.write('\n// Source fingerprint '+digest+'\n')
        argv,cwd,_=_resolve(str(snapshot),True);Pool,Bot=WasmPool,SandboxBot
    for queen in [0,1,2]:
        for length in [2,3,4,5,8,9,13]:
            own=own_body(length);opponent=[(7,5),(8,5)]
            teams=[(0,own if queen==0 else opponent),(1,own if queen==1 else opponent)]
            teams.extend([(0,[(13,12),(12,12)]),(1,[(13,14),(12,14)])])
            if queen==2:
                teams=[(0,[(13,12),(12,12)]),(1,[(13,14),(12,14)]),(0,own),(1,opponent),(0,[(2,2),(3,2)])]
            live=None;pool=None;record=None;post=None;deaths=[];peak=0
            def spawn(i,data):
                global live,pool
                if i==queen:
                    pool=Pool(argv,cwd=str(cwd),size=1,key=f'0000000000000007-{queen}')
                    live=Bot(pool,init=data,name=str(i))
            def reply(i,data):
                global record,post,peak
                r=int(data.splitlines()[0].split()[1])
                if r>=1:
                    if i==queen:
                        post=int(next(l.split()[1] for l in data.decode().splitlines() if l.startswith('LENGTH ')));raise Done()
                    if any(d[0]==queen for d in deaths):raise Done()
                if i!=queen:return b'MOVE N\n'
                out=live.ask(data);assert not live.error,live.error
                metrics=getattr(live,'live',None)
                if metrics and metrics[0]:peak=max(peak,metrics[0])
                record=out.decode();assert any(l.startswith('MOVE ') for l in record.splitlines()),record
                return out
            try:EngineModule().run(board(teams),reply,lambda i,r,w:deaths.append((i,r,w)),spawn,on_notice=lambda _:None,seed=7)
            except Done:pass
            finally:
                if live:live.stop()
                if pool:pool.close()
            assert post and not any(d[0]==queen for d in deaths),(queen,length,record,post,deaths)
            results.append({'case':f'unit{queen}_policy_L{length}','action':next(l for l in record.splitlines() if l.startswith('MOVE ')),'post':post,'peak_points':peak})
    print(json.dumps({'engine':version,'mode':'wasm' if args.wasm else 'native','cases':len(results),'policy':[r for r in results if '_policy_' in r['case']]},indent=2))
    print('PASS',len(results),'new-rule engine cases')
