"""Actual-engine feeding checks with a scripted, collision-free late-game prelude.

Only the donor and receiver use the candidate after the selected phase starts.
Earlier outputs retain sonar/protocol but use scripted moves to hold the fixture.
This checks execution and pickup, not competitive strength.
"""
from pathlib import Path
import json, os, subprocess, tempfile, sys
from unswbc.engine import EngineModule
from unswbc.bot import Pool, Bot

root=Path(__file__).resolve().parents[1]
class Done(Exception): pass

def run(binary, donor_length=4, receiver_length=20, phase=430, receiver_first=False, two_donors=False):
    def dragon(team, length, x, y):
        return f'DRAGON {team} {length} '+ ' '.join(f'{(x+j)%40} {y}' for j in range(length))+'\n'
    donor=dragon(0,donor_length,6,7 if donor_length==2 else 9)
    receiver=dragon(0,receiver_length,8,7)
    dragons=[receiver,donor] if receiver_first else [donor,receiver]
    donor_id,receiver_id=(1,0) if receiver_first else (0,1)
    if two_donors:dragons.append(dragon(0,4,6,5))
    for y in (13,17,21,25,29,33)[:8-len(dragons)]:dragons.append(dragon(0,2,20,y))
    dragons.append(dragon(1,2,32,37))
    board='MAP 40 40\nMAP_NAME feed_fixture\nTILE_COUNT 0\nEDGE_COUNT 0\nDRAGON_COUNT '+str(len(dragons))+'\n'+''.join(dragons)+'END\n'
    controlled={donor_id,receiver_id}|({2} if two_donors else set())
    pools=[];live={};records=[];deaths=[];errors=[];peak_points=0
    for i in sorted(controlled):pools.append(Pool([str(binary)],cwd=str(root),size=1,key=str(i)))
    pool_by_id=dict(zip(sorted(controlled),pools))
    def spawn(i,init):
        if i in controlled:live[i]=Bot(pool_by_id[i],init=init,name=str(i))
    def reply(i,block):
        nonlocal peak_points
        lines=block.decode().splitlines();r=int(lines[0].split()[1])
        if r>=min(500,phase+12):raise Done()
        if i not in live or r<phase-30:return b'MOVE W\nPROTOCOL 3\n'
        data=live[i].ask(block)
        metrics=getattr(live[i],"live",None)
        if metrics and metrics[0]:peak_points=max(peak_points,metrics[0])
        if live[i].error:errors.append({'id':i,'round':r,'error':str(live[i].error)})
        if r<phase:
            # Preserve the real candidate's reports to exercise length discovery.
            auxiliary=[l for l in data.decode().splitlines() if l.startswith(('SONAR ','PROTOCOL '))]
            return ('MOVE W\n'+'\n'.join(auxiliary)+'\n').encode()
        length=int(next(l.split()[1] for l in lines if l.startswith('LENGTH ')))
        action=next((l for l in data.decode().splitlines() if l.startswith(('MOVE ','SPLIT '))),'NONE')
        records.append({'id':i,'round':r,'length':length,'action':action})
        return data
    def death(i,r,why):
        deaths.append({'id':i,'round':r,'reason':why})
        b=live.pop(i,None)
        if b:b.stop()
    try:EngineModule().run(board.encode(),reply,death,spawn,on_notice=lambda s:None,seed=7)
    except Done:pass
    finally:
        for b in live.values():b.stop()
        for p in pools:p.close()
    result={'donor_length':donor_length,'receiver_length':receiver_length,'phase':phase,
            'receiver_first':receiver_first,'two_donors':two_donors,'turns':records,'deaths':deaths,'errors':errors,'peak_points':peak_points}
    assert not errors,result
    assert not any(d['id']==receiver_id for d in deaths),result
    # This fixture maintains eight teammates; donors above 18 cannot feed.
    should_feed=donor_length<=18 and receiver_length>=donor_length+2 and phase<=495
    donations=[d for d in deaths if d['id'] in controlled-{receiver_id} and d['reason']=='A' and d['round']>=phase]
    if should_feed:
        assert donations,result
        lengths=[t['length'] for t in records if t['id']==receiver_id]
        expected=receiver_length+(donor_length+1)//2+(2 if two_donors else 0)
        assert max(lengths)==expected,result
        if two_donors:assert len(donations)==2,result
    else:assert not donations,result
    print(json.dumps({'case':{k:result[k] for k in ['donor_length','receiver_length','phase','receiver_first','two_donors']},
                      'donations':donations,'receiver_peak':max(t['length'] for t in records if t['id']==receiver_id),
                      'errors':len(errors),'peak_points':peak_points}),flush=True)
    return result

with tempfile.TemporaryDirectory(prefix='feed-engine-') as tmp:
    if len(sys.argv)>1 and sys.argv[1]=='--wasm':
        import unswbc.sandbox as sandbox
        sandbox._cache_dir=lambda:Path(tmp)/'cache'
        Pool,Bot=sandbox.WasmPool,sandbox.SandboxBot
        binary=Path(sys.argv[2]).resolve()
    else:
        binary=Path(tmp)/'bot'
        subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
    results=[run(binary,donor_length=2),run(binary),run(binary,receiver_first=True),run(binary,two_donors=True),
             run(binary,receiver_length=5),run(binary,donor_length=19,receiver_length=25),run(binary,donor_length=2,phase=495),run(binary,donor_length=2,phase=498)]
    output=Path(os.environ.get('V5_FEED_ENGINE_OUT','/tmp/v5-feed-engine-results.json'))
    output.write_text(json.dumps(results,indent=2))
    print('Saved',output)
