"""Exercise unmodified V5 sprint decisions against the actual game engine."""
from pathlib import Path
import subprocess,tempfile,json,argparse,shutil,hashlib
parser=argparse.ArgumentParser();parser.add_argument("--mode",choices=["native","wasm"],default="native")
args=parser.parse_args()
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
root=Path(__file__).resolve().parents[1]
class Done(Exception):pass

def run(argv,cwd,name,length=4,pearls=(),attack=0,rescue=False):
    own=[(5,5),(4,5),(3,5),(3,4)][:length]
    enemy=[(6,6),(7,6)]
    rows=[];edges=[]
    if attack==3:enemy=[(7,6),(6,6),(5,6)]
    if attack==5:enemy=[(7,6),(6,6),(6,7),(7,7),(8,7)]
    if rescue:
        own=[(5,5),(4,5),(3,5),(2,5),(2,4),(2,3),(2,2),(3,2)]
        enemy=[(6,6),(7,6),(7,7),(8,7)]
        edges=[(175,1,-1),(176,2,23),(311,2,23)]
        for y in range(6,9):edges.extend([(y*34+22,1,-1),(y*34+23,1,-1)])
    rows=[(1,enemy),(0,own)]
    if attack:rows.append((0,[(2,7),(2,8)]))
    board=f'MAP 16 16\nMAP_NAME sprint_{name}\nTILE_COUNT {len(pearls)}\n'
    board+=''.join(f'TILE {x} {y} 1 1\n' for x,y in pearls)
    board+=f'EDGE_COUNT {len(edges)}\n'+''.join(f'EDGE {k} {t} {p}\n' for k,t,p in edges)
    board+=f'DRAGON_COUNT {len(rows)}\n'
    for team,cells in rows:board+=f'DRAGON {team} {len(cells)} '+' '.join(f'{x} {y}' for x,y in cells)+'\n'
    board+='END\n'
    pools={};live={};records=[];deaths=[];errors=[];spawns=[];post=None;peak=0
    def spawn(i,init):
        spawns.append(i)
        if i==1 or (rescue and i>=2):
            pools[i]=Pool(argv,cwd=str(cwd),size=1,key=str(i))
            live[i]=Bot(pools[i],init=init,name=str(i))
    def reply(i,block):
        nonlocal post,peak
        lines=block.decode().splitlines();r=int(lines[0].split()[1])
        size=int(next(l.split()[1] for l in lines if l.startswith('LENGTH ')))
        if r>=1:
            if i==1:post={'length':size};raise Done()
            if i==0 and any(d['id']==1 for d in deaths):raise Done()
        if i==0:return b'MOVE N\n'
        if i not in live:return b'MOVE N\n'
        output=live[i].ask(block)
        metrics=getattr(live[i],'live',None)
        if metrics and metrics[0]:peak=max(peak,metrics[0])
        if live[i].error:errors.append(str(live[i].error))
        action=next((l for l in output.decode().splitlines() if l.startswith(('MOVE ','SPLIT '))),'NONE')
        records.append({'id':i,'round':r,'length':size,'action':action})
        return output
    def death(i,r,why):deaths.append({'id':i,'round':r,'reason':why})
    try:EngineModule().run(board.encode(),reply,death,spawn,on_notice=lambda _:None,seed=7)
    except Done:pass
    finally:
        for bot in live.values():bot.stop()
        for pool in pools.values():pool.close()
    result={'case':name,'turns':records,'post':post,'deaths':deaths,'errors':errors,'spawns':spawns,'peak_points':peak}
    assert not errors,result
    action=next(t['action'] for t in records if t['id']==1 and t['round']==0)
    if attack:
        assert action=='MOVE EE',result
        assert any(d['id']==0 for d in deaths),result
        if attack==3:assert any(d['id']==1 for d in deaths),result
    elif rescue:
        assert action=='SPLIT 6',result
        assert post and post['length']==2,result
        assert any(t['id']>=2 and t['length']==6 for t in records),result
        assert not any(d['id']>=1 for d in deaths),result
    else:
        assert action.startswith('MOVE '),result
        steps=len(action.split()[1]);expected=3 if length>=4 or len(pearls)>=2 else 2 if length==3 else 1
        assert steps==expected and steps<=3,result
        assert post and post['length']==2,result
        assert not any(d['id']==1 for d in deaths),result
    print(json.dumps(result),flush=True)
    return result

with tempfile.TemporaryDirectory(prefix='sprint-engine-') as tmp:
    if args.mode=='wasm':
        from unswbc.run import _resolve
        from unswbc.sandbox import WasmPool,SandboxBot
        import unswbc.sandbox as sandbox
        sandbox._cache_dir=lambda:Path(tmp)/'cache'
        snapshot=Path(tmp)/'source';snapshot.mkdir()
        for p in root.iterdir():
            if p.suffix in ('.hpp','.cpp') or p.name=='bot.toml':shutil.copy2(p,snapshot/p.name)
        digest=hashlib.sha256(b''.join(p.read_bytes() for p in sorted(snapshot.iterdir()))).hexdigest()
        with (snapshot/'main.cpp').open('a') as f:f.write('\n// Source fingerprint '+digest+'\n')
        argv,cwd,_=_resolve(str(snapshot),True);Pool,Bot=WasmPool,SandboxBot
    else:
        binary=Path(tmp)/'bot'
        subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
        argv,cwd=[str(binary)],root
    results=[run(argv,cwd,'escape4'),run(argv,cwd,'escape3',3),run(argv,cwd,'escape2',2),
             run(argv,cwd,'early_pearls',2,[(5,4),(5,3)]),run(argv,cwd,'late_pearl',2,[(5,3)]),
             run(argv,cwd,'equal_short',4,attack=3),run(argv,cwd,'funded_attack',2,[(6,5)],attack=5),
             run(argv,cwd,'split_rescue',8,rescue=True)]
    print('PASS',len(results),'real-engine sprint cases',args.mode)
