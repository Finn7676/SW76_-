"""Check actual head trades and multi-enemy spacing with the engine."""
from pathlib import Path
import subprocess,tempfile,json
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
root=Path(__file__).resolve().parents[1]
class Done(Exception):pass

def run(binary,length,other=False,body_only=False):
    enemy=[(6,4),(7,4),(7,3),(6,3)][:min(length,4)]
    # The single-enemy cases compare equal short dragons. In multi-enemy
    # cases the target remains length four while our length varies.
    own=[((5-i)%16,5) for i in range(length)]
    rows=[(1,enemy),(0,own),(0,[(2,7),(2,8)])]
    if other:rows.append((1,[(1,2),(2,2)] if body_only else [(2,2),(2,3)]))
    board='MAP 16 16\nMAP_NAME enemy_contact\nTILE_COUNT 0\nEDGE_COUNT 0\nDRAGON_COUNT '+str(len(rows))+'\n'
    for team,cells in rows:board+=f'DRAGON {team} {len(cells)} '+' '.join(f'{x} {y}' for x,y in cells)+'\n'
    board+='END\n'
    pool=Pool([str(binary)],cwd=str(root),size=1,key='enemy-contact')
    live={};records=[];deaths=[];errors=[]
    def spawn(i,init):
        if i==1:live[i]=Bot(pool,init=init,name='candidate')
    def reply(i,block):
        lines=block.decode().splitlines();round=int(lines[0].split()[1])
        if round>0:raise Done()
        if i==0:return b'MOVE S\n'
        if i==2:return b'MOVE N\n'
        if i==3:return b'MOVE W\n'
        output=live[i].ask(block)
        if live[i].error:errors.append(str(live[i].error))
        action=next((line for line in output.decode().splitlines() if line.startswith(('MOVE ','SPLIT '))),'NONE')
        records.append(action);return output
    def death(i,round,why):deaths.append({'id':i,'round':round,'reason':why})
    try:EngineModule().run(board.encode(),reply,death,spawn,on_notice=lambda _:None,seed=7)
    except Done:pass
    finally:
        for bot in live.values():bot.stop()
        pool.close()
    result={'length':length,'another_enemy':other,'body_only':body_only,'actions':records,'deaths':deaths,'errors':errors}
    assert not errors and len(records)==1,result
    if not other:
        assert records==['MOVE E'],result
        assert {0,1}.issubset({d['id'] for d in deaths}),result
    else:
        # W runs into our own neck; E touches the target; N sits beside its
        # body after it moves south. S is the separated, physically legal move.
        assert records[0].startswith('MOVE S') and len(records[0].split()[1])<=3,result
        assert not any(d['id']==1 for d in deaths),result
    print(json.dumps(result),flush=True)
    return result
with tempfile.TemporaryDirectory(prefix='enemy-contact-engine-') as tmp:
    binary=Path(tmp)/'bot';subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
    for length in [2,3,4]:run(binary,length)
    for length in [2,3,4,8,12]:
        for body_only in [False,True]:run(binary,length,True,body_only)
