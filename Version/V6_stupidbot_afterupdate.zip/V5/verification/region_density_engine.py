"""Actual V5 bots in kelp rooms with real gaps and an opposing pearl target."""
from pathlib import Path
import argparse,subprocess,tempfile,json,shutil,hashlib
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['native','wasm'],default='native');args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
class Done(Exception):pass

def run(argv,cwd,name,count=3,gap='E',sea=False,disabled=False):
    x0,x1,y0,y1=(6,10,6,9)
    walls=[]
    if not sea:
        for x in range(x0,x1+1):
            if gap!='N' or x not in [8,9]:walls.append(y0*34+x)
            walls.append((y1+1)*34+x)
        for y in range(y0,y1+1):
            walls.append(y*34+17+x0)
            if gap!='E' or y not in [7,8]:walls.append(y*34+17+x1+1)
    residents=[[(7,6),(6,6)],[(9,6),(10,6)]][:count-1]
    own=[(8,8),(8,9)];rows=[(0,c) for c in residents]+[(0,own),(1,[(14,14),(13,14)])]
    candidate=len(residents)
    pearl=(7,8)
    board=f'MAP 16 16\nMAP_NAME density_{name}\nTILE_COUNT 1\nTILE {pearl[0]} {pearl[1]} 1 1\nEDGE_COUNT {len(walls)}\n'
    board+=''.join(f'EDGE {k} 1 -1\n' for k in walls)+f'DRAGON_COUNT {len(rows)}\n'
    for team,cells in rows:board+=f'DRAGON {team} {len(cells)} '+' '.join(f'{x} {y}' for x,y in cells)+'\n'
    board+='END\n'
    pool=Pool(argv,cwd=str(cwd),size=1,key=name);live={};records=[];errors=[];deaths=[];peak=0
    def spawn(i,init):
        if i<=candidate:live[i]=Bot(pool,init=init,name=str(i))
    def reply(i,block):
        nonlocal peak
        lines=block.decode().splitlines();r=int(lines[0].split()[1])
        if r>=5:raise Done()
        if i not in live:return b'MOVE E\n'
        output=live[i].ask(block)
        metrics=getattr(live[i],'live',None)
        if metrics and metrics[0]:peak=max(peak,metrics[0])
        if live[i].error:errors.append(str(live[i].error))
        head=next(l.split() for l in lines if len(l.split())==6 and l.split()[0]=='A' and l.split()[1]==str(i) and l.split()[5]=='1')
        size=int(next(l.split()[1] for l in lines if l.startswith('LENGTH ')))
        action=next((l for l in output.decode().splitlines() if l.startswith(('MOVE ','SPLIT '))),'NONE')
        records.append({'id':i,'round':r,'head':list(map(int,head[2:4])),'length':size,'action':action})
        return output
    def death(i,r,why):deaths.append({'id':i,'round':r,'reason':why})
    try:EngineModule().run(board.encode(),reply,death,spawn,on_notice=lambda _:None,seed=7)
    except Done:pass
    finally:
        for b in live.values():b.stop()
        pool.close()
    result={'case':name,'candidate':candidate,'turns':[t for t in records if t['id']==candidate],
            'errors':errors,'deaths':deaths,'peak_points':peak}
    assert not errors,result
    first=result['turns'][0]['action']
    if disabled or count==2 or sea:
        assert first=='MOVE W',result
    else:
        assert first=='MOVE '+gap,result
        assert not any(d['id']==candidate for d in deaths),result
        assert any(not(x0<=t['head'][0]<=x1 and y0<=t['head'][1]<=y1) for t in result['turns']),result
        assert not any(t['action'].startswith('SPLIT ') for t in result['turns']),result
    print(json.dumps(result),flush=True)
    return result

with tempfile.TemporaryDirectory(prefix='density-engine-') as tmp:
    if args.mode=='wasm':
        from unswbc.run import _resolve
        from unswbc.sandbox import WasmPool,SandboxBot
        import unswbc.sandbox as sandbox
        sandbox._cache_dir=lambda:Path(tmp)/'cache';snapshot=Path(tmp)/'source';snapshot.mkdir()
        for p in root.iterdir():
            if p.suffix in ('.hpp','.cpp') or p.name=='bot.toml':shutil.copy2(p,snapshot/p.name)
        digest=hashlib.sha256(b''.join(p.read_bytes() for p in sorted(snapshot.iterdir()))).hexdigest()
        with (snapshot/'main.cpp').open('a') as f:f.write('\n// Source fingerprint '+digest+'\n')
        argv,cwd,_=_resolve(str(snapshot),True);Pool,Bot=WasmPool,SandboxBot
    else:
        binary=Path(tmp)/'bot';subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
        argv,cwd=[str(binary)],root
        baseline=Path(tmp)/'before';subprocess.run(['c++','-std=c++20','-O2','-DFEAT_REGION_DENSITY=0',str(root/'main.cpp'),'-o',str(baseline)],check=True)
        run([str(baseline)],root,'before_gap',disabled=True)
    results=[run(argv,cwd,'vertical_gap'),run(argv,cwd,'horizontal_gap',gap='N'),
             run(argv,cwd,'within_quota',2),run(argv,cwd,'open_sea',sea=True)]
    print('PASS',len(results),'real-engine density cases',args.mode)
