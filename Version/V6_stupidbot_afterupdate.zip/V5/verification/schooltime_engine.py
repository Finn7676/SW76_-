"""Reproduce edge-following and measure exploration; this is not a win-rate benchmark."""
from pathlib import Path
import sys,json,tempfile,subprocess,collections,shutil,hashlib,argparse
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
parser=argparse.ArgumentParser(description='Inspect Schooltime exploration using actual engine observations.')
parser.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[1])
parser.add_argument('--map',type=Path)
parser.add_argument('--rounds',type=int,default=160)
parser.add_argument('--mode',choices=['native','wasm'],default='native')
parser.add_argument('--output',type=Path,default=Path('/tmp/v5-schooltime-exploration.json'))
args=parser.parse_args();root=args.source.resolve();limit=args.rounds;label=args.mode
mapfile=args.map or root.parent/'maps/schooltime.map' 
class Done(Exception):pass
with tempfile.TemporaryDirectory(prefix='schooltime-trace-') as tmp:
 if args.mode=='wasm':
  from unswbc.run import _resolve
  from unswbc.sandbox import WasmPool,SandboxBot
  snapshot=Path(tmp)/'source';snapshot.mkdir()
  for p in root.iterdir():
   if p.suffix in ('.hpp','.cpp') or p.name=='bot.toml':shutil.copy2(p,snapshot/p.name)
  digest=hashlib.sha256(b''.join(p.read_bytes() for p in sorted(snapshot.iterdir()))).hexdigest()
  with (snapshot/'main.cpp').open('a') as f:f.write('\n// Full source fingerprint: '+digest+'\n')
  argv,cwd,_=_resolve(str(snapshot),True);Pool,Bot=WasmPool,SandboxBot
 else:
  binary=Path(tmp)/'bot';subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
  argv,cwd=[str(binary)],root
 pools={t:Pool(argv,cwd=str(cwd),size=1,key=f'0000000000000007-{t.lower()}') for t in ['A','B']}
 live={};teams={};records=[];errors=[];deaths=[];seen={t:set() for t in pools};peak_points=0
 def spawn(i,init):
  team=next(l.split()[1] for l in init.decode().splitlines() if l.startswith('TEAM '));teams[i]=team;live[i]=Bot(pools[team],init=init,name=str(i))
 def reply(i,block):
  global peak_points
  lines=block.decode().splitlines();r=int(lines[0].split()[1])
  if r>=limit:raise Done()
  out=live[i].ask(block)
  metrics=getattr(live[i],'live',None)
  if metrics and metrics[0]:peak_points=max(peak_points,metrics[0])
  if live[i].error:errors.append({'id':i,'round':r,'error':str(live[i].error)})
  head=next(l.split() for l in lines if len(l.split())==6 and l.split()[0] in ['A','B'] and l.split()[1]==str(i) and l.split()[5]=='1')
  action=next((l for l in out.decode().splitlines() if l.startswith(('MOVE ','SPLIT '))),'NONE')
  for l in lines:
   s=l.split()
   if len(s)==4 and all(v.lstrip('-').isdigit() for v in s):seen[teams[i]].add((int(s[0]),int(s[1])))
  records.append({'id':i,'round':r,'team':teams[i],'x':int(head[2]),'y':int(head[3]),'action':action})
  return out
 def death(i,r,why):
  deaths.append({'id':i,'round':r,'reason':why});b=live.pop(i,None)
  if b:b.stop()
 result=None
 try:result=EngineModule().run(mapfile.read_bytes(),reply,death,spawn,on_notice=lambda _:None,seed=7)
 except Done:pass
 finally:
  for b in live.values():b.stop()
  for p in pools.values():p.close()
 data={'records':records,'errors':errors,'deaths':deaths,'seen':{t:len(c) for t,c in seen.items()},'peak_points':peak_points}
 args.output.write_text(json.dumps(data))
 assert not errors,errors
 print(json.dumps({'label':label,'peak_points':peak_points,'turns':len(records),'errors':errors,'seen':data['seen'],'max_y':max(v['y'] for v in records),'top_last60':sum(v['y']<=3 for v in records if v['round']>=limit-60),'last60':sum(v['round']>=limit-60 for v in records),'first_deep':min((v['round'] for v in records if 10<=v['y']<34),default=None)}))
 for i in range(6):
  path=[v for v in records if v['id']==i];print(i,'max y',max((v['y'] for v in path),default=-1),'late',[(v['round'],v['x'],v['y'],v['action']) for v in path[-12:]])
