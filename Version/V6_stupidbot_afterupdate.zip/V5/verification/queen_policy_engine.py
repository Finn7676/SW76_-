"""Official-engine execution of boundary strategy snapshots (not 500-round win-rate tests).
Only the bot's ROUND label is injected; engine physics and ID order are unmodified.
"""
from pathlib import Path
import argparse,subprocess,tempfile,json,shutil,hashlib
from unswbc.engine import EngineModule
from unswbc.bot import Pool,Bot
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--wasm',action='store_true');args=p.parse_args()
class Done(Exception):pass
def board(teams,pearls=(),walls=()):
    text='MAP 16 16\nMAP_NAME queen_policy_snapshot\nTILE_COUNT '+str(len(pearls))+'\n'
    text+=''.join(f'TILE {x} {y} 1 1\n' for x,y in pearls)
    text+='EDGE_COUNT '+str(len(walls))+'\n'+''.join(f'EDGE {k} 1 -1\n' for k in walls)
    text+='DRAGON_COUNT '+str(len(teams))+'\n'
    for team,cells in teams:text+=f'DRAGON {team} {len(cells)} '+' '.join(f'{x} {y}' for x,y in cells)+'\n'
    return (text+'END\n').encode()
with tempfile.TemporaryDirectory(prefix='queen-policy-engine-') as temporary:
    tmp=Path(temporary);binary=tmp/'bot'
    subprocess.run(['c++','-std=c++20','-O2',str(root/'main.cpp'),'-o',str(binary)],check=True)
    argv,cwd=[str(binary)],root
    if args.wasm:
        from unswbc.run import _resolve
        from unswbc.sandbox import WasmPool,SandboxBot
        import unswbc.sandbox as sandbox
        sandbox._cache_dir=lambda:tmp/'cache'
        source=tmp/'source';source.mkdir()
        for file in root.iterdir():
            if file.suffix in ('.hpp','.cpp') or file.name=='bot.toml':shutil.copy2(file,source/file.name)
        digest=hashlib.sha256(b''.join(file.read_bytes() for file in sorted(source.iterdir()))).hexdigest()
        with (source/'main.cpp').open('a') as fp:fp.write('\n// Queen policy '+digest+'\n')
        argv,cwd,_=_resolve(str(source),True);Pool,Bot=WasmPool,SandboxBot
    results=[]
    def case(name,teams,target,round_num,kill=False,split=False):
        live=pool=None;action=None;post=None;deaths=[];peak=0
        def spawn(i,data):
            nonlocal live,pool
            if i==target:
                pool=Pool(argv,cwd=str(cwd),size=1,key=f'0000000000000007-{i}')
                live=Bot(pool,init=data,name=str(i))
        def reply(i,data):
            nonlocal action,post,peak
            actual_round=int(data.splitlines()[0].split()[1])
            if actual_round>=1:
                if i==target:
                    post=int(next(l.split()[1] for l in data.decode().splitlines() if l.startswith('LENGTH ')));raise Done()
                if any(d[0]==target for d in deaths):raise Done()
            if i!=target:
                if i==1 and actual_round>=1:return b'MOVE N\n'
                return b'SPLIT 2\n' if target==2 and i==1 and actual_round==0 else b'MOVE E\n'
            lines=data.splitlines();lines[0]=lines[0].split()[0]+b' '+str(round_num).encode()
            out=live.ask(b'\n'.join(lines)+b'\n');assert not live.error,live.error
            metrics=getattr(live,'live',None)
            if metrics and metrics[0]:peak=max(peak,metrics[0])
            action=next(l for l in out.decode().splitlines() if l.startswith(('MOVE ','SPLIT ')))
            return out
        try:EngineModule().run(board(teams),reply,lambda i,r,w:deaths.append((i,r,w)),spawn,on_notice=lambda _:None,seed=7)
        except Done:pass
        finally:
            if live:live.stop()
            if pool:pool.close()
        if kill:assert any(d[0]==1 for d in deaths) and any(d[0]==2 for d in deaths),(name,action,deaths,post)
        elif target==2:assert post and not any(d[0] in (1,2) for d in deaths),(name,action,deaths,post)
        else:
            assert post==(3 if split else 6),(name,action,deaths,post)
            assert action.startswith('SPLIT ')==split,(name,action)
        results.append({'case':name,'action':action,'post_length':post,'deaths':deaths,'peak_points':peak})
    own=[(5,5),(4,5),(3,5),(3,6),(4,6),(5,6)]
    far=[(13,12),(12,12)]
    for queen in (0,1):
        for round_num in (149,150):
            teams=[(0,own if queen==0 else far),(1,own if queen==1 else far)]
            case(f'queen{queen}_round{round_num}',teams,queen,round_num,split=round_num<150)
    for round_num in (399,400):
        for length in (2,4,5):
            teams=[(0,far),(1,[(6,5),(7,5),(8,5),(9,5)]),(0,own[:length])]
            case(f'attack_L{length}_round{round_num}',teams,2,round_num,kill=round_num>=400 or length<=4)

    def rescue_case(queen,round_num):
        target=2 if queen==0 else 3
        blocker=[(7,5),(7,6),(6,6),(5,6),(5,5)]
        qbody=[(6,4),(6,3)]
        teams=[(0,qbody if queen==0 else far),(1,qbody if queen==1 else far)]
        teams.append((0,blocker if queen==0 else [(13,14),(12,14)]))
        if queen==1:teams.append((1,blocker))
        live=pool=None;record=None;queen_post=None;deaths=[];peak=0
        def spawn(i,data):
            nonlocal live,pool
            if i==target:
                pool=Pool(argv,cwd=str(cwd),size=1,key=f'0000000000000007-{i}')
                live=Bot(pool,init=data,name=str(i))
        def reply(i,data):
            nonlocal record,queen_post,peak
            actual=int(data.splitlines()[0].split()[1])
            if actual>=2 and i==queen:
                queen_post=int(next(l.split()[1] for l in data.decode().splitlines() if l.startswith('LENGTH ')))
                raise Done()
            if i==queen:return b'MOVE S\n' if actual==0 else b'MOVE E\n'
            if i!=target:return b'MOVE E\n'
            lines=data.splitlines();lines[0]=lines[0].split()[0]+b' '+str(round_num).encode()
            record=live.ask(b'\n'.join(lines)+b'\n');assert not live.error,live.error
            metrics=getattr(live,'live',None)
            if metrics and metrics[0]:peak=max(peak,metrics[0])
            assert not any(l.startswith((b'MOVE ',b'SPLIT ')) for l in record.splitlines()),record
            return record
        try:EngineModule().run(board(teams,[(8,5)],[5*(2*16+2)+7]),reply,lambda i,r,w:deaths.append((i,r,w)),spawn,on_notice=lambda _:None,seed=7)
        except Done:pass
        finally:
            if live:live.stop()
            if pool:pool.close()
        assert any(d[0]==target and d[1]==0 for d in deaths) and not any(d[0]==queen for d in deaths),deaths
        assert queen_post==3,(queen,queen_post,deaths)
        results.append({'case':f'queen{queen}_rescue_round{round_num}','action':'SUICIDE (no movement)',
                        'post_length':queen_post,'deaths':deaths,'peak_points':peak})
    for queen in (0,1):
        for round_num in (20,430):rescue_case(queen,round_num)
    print(json.dumps({'mode':'wasm' if args.wasm else 'native','cases':results},indent=2))
    print('PASS',len(results),'official-engine policy snapshots')
